from sklearn.datasets import load_breast_cancer
from sklearn.model_selection import train_test_split
from sklearn.svm import SVC
from sklearn.metrics import accuracy_score
from sklearn.preprocessing import StandardScaler

X, y = load_breast_cancer(return_X_y=True)

X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)

scaler = StandardScaler()
X_train_scaled = scaler.fit_transform(X_train)
X_test_scaled = scaler.transform(X_test)

model = SVC(kernel='linear', random_state=42)
model.fit(X_train_scaled, y_train)

y_pred = model.predict(X_test_scaled)
print(accuracy_score(y_test, y_pred))

# ---------------------------------------------------------
# Short Explanation of SVM Program
# ---------------------------------------------------------

# This program uses the Breast Cancer dataset and applies
# the SVM (Support Vector Machine) algorithm for classification.

# Dataset is divided into training data and testing data
# using train_test_split().

# StandardScaler is used to normalize the data because
# SVM works better on scaled data.

# SVC(kernel='linear') creates the SVM model using
# a linear kernel.

# model.fit() trains the model using training data.

# model.predict() predicts output for testing data.

# accuracy_score() calculates the accuracy of the model.

# Finally, the program prints the prediction accuracy.
# ---------------------------------------------------------