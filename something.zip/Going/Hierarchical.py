from sklearn.datasets import load_iris
from sklearn.cluster import AgglomerativeClustering
from sklearn.preprocessing import StandardScaler

X, _ = load_iris(return_X_y=True)

scaler = StandardScaler()
X_scaled = scaler.fit_transform(X)

model = AgglomerativeClustering(n_clusters=3)
labels = model.fit_predict(X_scaled)

print(labels[:10])

# ---------------------------------------------------------
# Short Explanation of Agglomerative Clustering Program
# ---------------------------------------------------------

# This program uses the Iris dataset and applies
# the Agglomerative Clustering algorithm.

# StandardScaler() is used to normalize the data
# so all features have similar scale.

# AgglomerativeClustering(n_clusters=3)
# creates the clustering model with 3 clusters.

# Agglomerative Clustering is a hierarchical
# clustering method that merges nearest data points
# step-by-step to form clusters.

# fit_predict() trains the model and assigns
# cluster labels to data points.

# labels stores the cluster number of each data sample.

# print(labels[:10]) displays cluster labels
# of the first 10 data samples.
# ---------------------------------------------------------