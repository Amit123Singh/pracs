from sklearn.datasets import load_diabetes
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import PolynomialFeatures
from sklearn.linear_model import LinearRegression
from sklearn.metrics import mean_squared_error

X, y = load_diabetes(return_X_y=True)

X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)

poly = PolynomialFeatures(degree=2)
X_train_poly = poly.fit_transform(X_train)
X_test_poly = poly.transform(X_test)

model = LinearRegression()
model.fit(X_train_poly, y_train)

y_pred = model.predict(X_test_poly)
print(mean_squared_error(y_test, y_pred))

# ---------------------------------------------------------
# Short Explanation of Polynomial Regression Program
# ---------------------------------------------------------

# This program uses the Diabetes dataset and applies
# Polynomial Regression for prediction.

# train_test_split() divides the dataset into
# training and testing data.

# PolynomialFeatures(degree=2) converts normal
# features into polynomial features.

# This helps the model learn non-linear relationships
# between input and output data.

# LinearRegression() creates the regression model.

# model.fit() trains the model using polynomial data.

# model.predict() predicts output for test data.

# mean_squared_error() calculates prediction error.

# Lower error means better prediction performance.
# ---------------------------------------------------------