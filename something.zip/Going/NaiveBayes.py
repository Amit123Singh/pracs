from sklearn.datasets import load_iris
from sklearn.model_selection import train_test_split
from sklearn.naive_bayes import GaussianNB
from sklearn.metrics import accuracy_score

X, y = load_iris(return_X_y=True)

X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)

model = GaussianNB()
model.fit(X_train, y_train)

y_pred = model.predict(X_test)
print(accuracy_score(y_test, y_pred))

# ---------------------------------------------------------
# Short Explanation of Naive Bayes Program
# ---------------------------------------------------------

# This program uses the Iris dataset and applies
# the Naive Bayes classification algorithm.

# train_test_split() divides the dataset into
# training data and testing data.

# GaussianNB() creates the Naive Bayes model.

# Naive Bayes works on probability and predicts
# the most probable class.

# model.fit() trains the model using training data.

# model.predict() predicts class labels for test data.

# accuracy_score() calculates model accuracy.

# Higher accuracy means better classification performance.
# ---------------------------------------------------------