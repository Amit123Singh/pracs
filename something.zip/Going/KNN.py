from sklearn.datasets import load_iris
from sklearn.model_selection import train_test_split
from sklearn.neighbors import KNeighborsClassifier
from sklearn.metrics import accuracy_score
from sklearn.preprocessing import StandardScaler

X, y = load_iris(return_X_y=True)

X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)

scaler = StandardScaler()
X_train_scaled = scaler.fit_transform(X_train)
X_test_scaled = scaler.transform(X_test)

model = KNeighborsClassifier(n_neighbors=5)
model.fit(X_train_scaled, y_train)

y_pred = model.predict(X_test_scaled)
print(accuracy_score(y_test, y_pred))

# ---------------------------------------------------------
# Short Explanation of K-Nearest Neighbors (KNN) Program
# ---------------------------------------------------------

# This program uses the Iris dataset and applies
# the K-Nearest Neighbors (KNN) classification algorithm.

# train_test_split() divides the dataset into
# training data and testing data.

# StandardScaler() is used to normalize the data
# because KNN works better on scaled data.

# KNeighborsClassifier(n_neighbors=5)
# creates the KNN model with K = 5 neighbors.

# model.fit() trains the model using training data.

# model.predict() predicts class labels for test data.

# accuracy_score() calculates prediction accuracy.

# Higher accuracy means better classification performance.
# ---------------------------------------------------------