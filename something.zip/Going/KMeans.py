from sklearn.datasets import load_iris
from sklearn.cluster import KMeans
from sklearn.preprocessing import StandardScaler

X, _ = load_iris(return_X_y=True)

scaler = StandardScaler()
X_scaled = scaler.fit_transform(X)

model = KMeans(n_clusters=3, random_state=42, n_init=10)
labels = model.fit_predict(X_scaled)

print(labels[:10])

# ---------------------------------------------------------
# Short Explanation of K-Means Clustering Program
# ---------------------------------------------------------

# This program uses the Iris dataset and applies
# the K-Means Clustering algorithm.

# StandardScaler() is used to normalize the data
# so all features have similar scale.

# KMeans(n_clusters=3) creates the clustering model
# with 3 clusters/groups.

# fit_predict() trains the model and assigns
# cluster labels to data points.

# labels stores the cluster number of each data point.

# print(labels[:10]) displays cluster labels
# of the first 10 data samples.

# K-Means is an unsupervised learning algorithm
# used to group similar data points together.
# ---------------------------------------------------------