from sklearn.datasets import load_breast_cancer
from sklearn.model_selection import train_test_split
from sklearn.neural_network import MLPClassifier
from sklearn.metrics import accuracy_score
from sklearn.preprocessing import StandardScaler

X, y = load_breast_cancer(return_X_y=True)

X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)

scaler = StandardScaler()
X_train_scaled = scaler.fit_transform(X_train)
X_test_scaled = scaler.transform(X_test)

model = MLPClassifier(hidden_layer_sizes=(100,), max_iter=1000, random_state=42)
model.fit(X_train_scaled, y_train)

y_pred = model.predict(X_test_scaled)
print(accuracy_score(y_test, y_pred))

# ---------------------------------------------------------
# Short Explanation of Neural Network Program
# ---------------------------------------------------------

# This program uses the Breast Cancer dataset and applies
# the Neural Network classification algorithm.

# train_test_split() divides the dataset into
# training data and testing data.

# StandardScaler() is used to normalize the data
# because Neural Networks work better on scaled data.

# MLPClassifier() creates the Neural Network model
# with one hidden layer containing 100 neurons.

# model.fit() trains the model using training data.

# model.predict() predicts class labels for test data.

# accuracy_score() calculates prediction accuracy.

# Higher accuracy means better classification performance.
# ---------------------------------------------------------