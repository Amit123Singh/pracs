from sklearn.datasets import load_diabetes
from sklearn.model_selection import train_test_split
from sklearn.linear_model import Lasso, Ridge
from sklearn.metrics import mean_squared_error

X, y = load_diabetes(return_X_y=True)

X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)

lasso_model = Lasso(alpha=0.1)
lasso_model.fit(X_train, y_train)
y_pred_lasso = lasso_model.predict(X_test)

ridge_model = Ridge(alpha=1.0)
ridge_model.fit(X_train, y_train)
y_pred_ridge = ridge_model.predict(X_test)

print(mean_squared_error(y_test, y_pred_lasso))
print(mean_squared_error(y_test, y_pred_ridge))

# ---------------------------------------------------------
# Short Explanation of Lasso and Ridge Regression Program
# ---------------------------------------------------------

# This program uses the Diabetes dataset and applies
# Lasso Regression and Ridge Regression algorithms.

# train_test_split() divides the dataset into
# training data and testing data.

# Lasso() creates the Lasso Regression model.
# It helps reduce unnecessary features using regularization.

# Ridge() creates the Ridge Regression model.
# It reduces overfitting by controlling large coefficients.

# model.fit() trains both models using training data.

# model.predict() predicts output values for test data.

# mean_squared_error() calculates prediction error
# for both Lasso and Ridge models.

# Lower error value means better model performance.
# ---------------------------------------------------------