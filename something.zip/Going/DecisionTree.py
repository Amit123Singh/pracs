from sklearn.datasets import load_iris
from sklearn.model_selection import train_test_split
from sklearn.tree import DecisionTreeClassifier
from sklearn.metrics import accuracy_score

X, y = load_iris(return_X_y=True)

X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)

model = DecisionTreeClassifier(random_state=42)
model.fit(X_train, y_train)

y_pred = model.predict(X_test)
print(accuracy_score(y_test, y_pred))

# ---------------------------------------------------------
# Short Explanation of Decision Tree Program
# ---------------------------------------------------------

# This program uses the Iris dataset and applies
# the Decision Tree classification algorithm.

# train_test_split() divides the dataset into
# training data and testing data.

# DecisionTreeClassifier() creates the Decision Tree model.

# Decision Tree works by making decisions based on
# conditions and splits the data into branches.

# model.fit() trains the model using training data.

# model.predict() predicts class labels for test data.

# accuracy_score() calculates prediction accuracy.

# Higher accuracy means better classification performance.
# ---------------------------------------------------------