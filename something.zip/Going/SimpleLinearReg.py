from sklearn.datasets import load_diabetes
from sklearn.model_selection import train_test_split
from sklearn.linear_model import LinearRegression
from sklearn.metrics import mean_squared_error

X, y = load_diabetes(return_X_y=True)
X = X[:, 2].reshape(-1, 1)

X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)

model = LinearRegression()
model.fit(X_train, y_train)

y_pred = model.predict(X_test)
print(mean_squared_error(y_test, y_pred))

# ---------------------------------------------------------
# Short Explanation of Linear Regression Program
# ---------------------------------------------------------

# This program uses the Diabetes dataset and applies
# the Linear Regression algorithm for prediction.

# load_diabetes() loads the dataset and selects
# one feature column for training.

# train_test_split() divides data into training
# and testing datasets.

# LinearRegression() creates the regression model.

# model.fit() trains the model using training data.

# model.predict() predicts output values for test data.

# mean_squared_error() calculates prediction error.

# Lower error value means better model performance.
# ---------------------------------------------------------