#include <iostream>
using namespace std;

int main() {

    int n;

    // Input number of vertices
    cout << "Enter number of vertices: ";
    cin >> n;

    /*
    Adjacency matrix representation
    */

    int graph[100][100];

    // Input adjacency matrix
    cout << "Enter adjacency matrix:\n";

    for(int i = 0; i < n; i++) {

        for(int j = 0; j < n; j++) {

            cin >> graph[i][j];

            /*
            Replace 0 with large value
            to represent infinity
            */

            if(graph[i][j] == 0) {
                graph[i][j] = 999;
            }
        }
    }

    int start;

    // Input source vertex
    cout << "Enter source vertex: ";
    cin >> start;

    /*
    distance[] stores shortest distance
    from source to every vertex
    */

    int distance[100];

    /*
    visited[] keeps track of visited vertices
    */

    int visited[100] = {0};

    /*
    Initialize distances from source
    */

    for(int i = 0; i < n; i++) {

        distance[i] = graph[start][i];
    }

    // Source distance is always 0
    distance[start] = 0;

    // Mark source visited
    visited[start] = 1;

    /*
    Repeat for remaining vertices
    */

    for(int count = 1; count < n - 1; count++) {

        int min = 999;

        int nextnode;

        /*
        Find vertex with minimum distance
        */

        for(int i = 0; i < n; i++) {

            if(!visited[i] && distance[i] < min) {

                min = distance[i];

                nextnode = i;
            }
        }

        // Mark selected vertex visited
        visited[nextnode] = 1;

        /*
        Update distances of adjacent vertices
        */

        for(int i = 0; i < n; i++) {

            /*
            If shorter path found
            */

            if(!visited[i] &&
               min + graph[nextnode][i] < distance[i]) {

                distance[i] =
                min + graph[nextnode][i];
            }
        }
    }

    /*
    Print shortest distances
    */

    cout << "\nShortest Distances:\n";

    for(int i = 0; i < n; i++) {

        cout << start
             << " -> "
             << i
             << " = "
             << distance[i]
             << endl;
    }

    return 0;
}

/*
========================================================
                DIJKSTRA'S ALGORITHM
========================================================

THEORY:
Dijkstra's Algorithm finds the shortest path
from a source vertex to all other vertices
in a weighted graph.

It works only for graphs with
NON-NEGATIVE edge weights.

--------------------------------------------------------
WORKING:
1. Start from source vertex.
2. Assign distance 0 to source.
3. Assign infinity to all other vertices.
4. Select unvisited vertex with minimum distance.
5. Update distances of adjacent vertices.
6. Repeat until all vertices are visited.

--------------------------------------------------------
TIME COMPLEXITY:
O(V^2)

where:
V = Number of vertices

--------------------------------------------------------
APPLICATIONS:
- GPS Navigation
- Network Routing
- Shortest Path Problems

--------------------------------------------------------
EXAMPLE:

Graph:

0 ---4--- 1
|         |
2         5
|         |
2 ---1--- 3

Shortest distance from 0:
0 -> 1 = 4
0 -> 2 = 2
0 -> 3 = 3

========================================================
*/