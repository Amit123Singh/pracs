#include <iostream>
#include <queue>
using namespace std;

int main() {

    int n, e;

    // Input number of vertices and edges
    cout << "Enter number of vertices and edges: ";
    cin >> n >> e;

    /*
    Adjacency Matrix Representation
    */

    int graph[100][100] = {0};

    // Input edges
    cout << "Enter edges:\n";

    for(int i = 0; i < e; i++) {

        int u, v;

        cin >> u >> v;

        // Undirected graph
        graph[u][v] = 1;
        graph[v][u] = 1;
    }

    /*
    visited[] keeps track of visited nodes
    */

    int visited[100] = {0};

    /*
    Queue used in BFS
    */

    queue<int> q;

    int start;

    // Input starting vertex
    cout << "Enter starting vertex: ";
    cin >> start;

    /*
    Mark start node visited
    and push into queue
    */

    visited[start] = 1;

    q.push(start);

    cout << "\nBFS Traversal: ";

    /*
    Continue until queue becomes empty
    */

    while(!q.empty()) {

        // Get front element
        int u = q.front();

        // Remove front element
        q.pop();

        // Print node
        cout << u << " ";

        /*
        Visit all adjacent vertices
        */

        for(int v = 0; v < n; v++) {

            /*
            If edge exists and node
            is not visited
            */

            if(graph[u][v] == 1 && !visited[v]) {

                // Mark visited
                visited[v] = 1;

                // Push into queue
                q.push(v);
            }
        }
    }

    return 0;
}

/*
========================================================
            BREADTH FIRST SEARCH (BFS)
========================================================

THEORY:
BFS traverses graph level by level.

It first visits all neighbors of current node,
then moves to next level.

BFS uses QUEUE data structure.

--------------------------------------------------------
WORKING:
1. Start from source node.
2. Mark node as visited.
3. Insert node into queue.
4. Remove front node from queue.
5. Visit all unvisited neighbors.
6. Repeat until queue becomes empty.

--------------------------------------------------------
TIME COMPLEXITY:
O(V + E)

where:
V = Vertices
E = Edges

--------------------------------------------------------
APPLICATIONS:
- Shortest path in unweighted graph
- Network traversal
- Web crawling

========================================================
*/