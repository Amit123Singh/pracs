#include <iostream>
using namespace std;

int main() {

    int n;

    // Variable to count comparisons
    int comparisons = 0;

    // Input size of array
    cout << "Enter number of elements: ";
    cin >> n;

    // Declare array
    int arr[n];

    // Input array elements
    cout << "Enter elements:\n";

    for(int i = 0; i < n; i++) {
        cin >> arr[i];
    }

    /*
    ----------------------------------------------------
    INSERTION SORT LOGIC
    ----------------------------------------------------
    Start from second element because first element
    is already considered sorted.
    */

    for(int i = 1; i < n; i++) {

        // Store current element
        int key = arr[i];

        // Previous index
        int j = i - 1;

        /*
        Compare key with all previous elements.

        Shift elements greater than key
        one position ahead.
        */

        while(j >= 0) {

            // Count comparison
            comparisons++;

            if(arr[j] > key) {

                // Shift element to right
                arr[j + 1] = arr[j];

                // Move left
                j--;
            }
            else {

                // Correct position found
                break;
            }
        }

        // Insert key at correct position
        arr[j + 1] = key;
    }

    // Display sorted array
    cout << "\nSorted Array:\n";

    for(int i = 0; i < n; i++) {
        cout << arr[i] << " ";
    }

    // Display number of comparisons
    cout << "\nComparisons = " << comparisons;

    return 0;
}

/*
========================================================
                    INSERTION SORT
========================================================

THEORY:
Insertion Sort works by taking one element at a time
and placing it at its correct position in the already
sorted part of the array.

It is similar to arranging playing cards.

--------------------------------------------------------
ALGORITHM:
1. Assume first element is already sorted.
2. Pick next element as KEY.
3. Compare KEY with previous elements.
4. Shift larger elements one position right.
5. Insert KEY at correct position.
6. Repeat until array is sorted.

--------------------------------------------------------
TIME COMPLEXITY:
Best Case    : O(n)
Worst Case   : O(n^2)
Average Case : O(n^2)

SPACE COMPLEXITY:
O(1)

--------------------------------------------------------
EXAMPLE:
Array = 5 3 4 1

Pass 1:
3 inserted before 5
3 5 4 1

Pass 2:
4 inserted between 3 and 5
3 4 5 1

Pass 3:
1 inserted at beginning
1 3 4 5

========================================================
*/