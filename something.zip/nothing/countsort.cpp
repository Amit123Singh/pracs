#include <iostream>
using namespace std;

int main() {

    int n;

    // Input size of array
    cout << "Enter number of elements: ";
    cin >> n;

    int arr[n];

    // Input array elements
    cout << "Enter elements:\n";

    for(int i = 0; i < n; i++) {
        cin >> arr[i];
    }

    /*
    ----------------------------------------------------
    Find maximum element
    ----------------------------------------------------
    */

    int max = arr[0];

    for(int i = 1; i < n; i++) {

        if(arr[i] > max) {
            max = arr[i];
        }
    }

    /*
    ----------------------------------------------------
    Create count array
    Size = max + 1
    ----------------------------------------------------
    */

    int count[max + 1] = {0};

    /*
    Store frequency of each element
    */

    for(int i = 0; i < n; i++) {
        count[arr[i]]++;
    }

    /*
    Print sorted array
    */

    cout << "\nSorted Array:\n";

    for(int i = 0; i <= max; i++) {

        while(count[i] > 0) {

            cout << i << " ";

            count[i]--;
        }
    }

    return 0;
}

/*
========================================================
                      COUNT SORT
========================================================

THEORY:
Count Sort is a non-comparison sorting algorithm.

It works by counting frequency of each element.

--------------------------------------------------------
WORKING:
1. Find maximum element.
2. Create count array.
3. Store frequency of each element.
4. Print elements according to frequency.

--------------------------------------------------------
TIME COMPLEXITY:
Best Case    : O(n + k)
Worst Case   : O(n + k)

where:
n = number of elements
k = maximum element

SPACE COMPLEXITY:
O(k)

--------------------------------------------------------
IMPORTANT:
Count Sort works only for:
- Non-negative integers
- Small range of values

--------------------------------------------------------
EXAMPLE:
Array = 4 2 2 8 3 3 1

Count Array:
1 -> 1 time
2 -> 2 times
3 -> 2 times
4 -> 1 time
8 -> 1 time

Sorted Array:
1 2 2 3 3 4 8

========================================================
*/