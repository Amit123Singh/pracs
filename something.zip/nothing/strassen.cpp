#include <iostream>
using namespace std;

void strassen(int A[2][2], int B[2][2], int C[2][2]) {

    // Calculate 7 products
    int P1 = (A[0][0] + A[1][1]) * (B[0][0] + B[1][1]);

    int P2 = (A[1][0] + A[1][1]) * B[0][0];

    int P3 = A[0][0] * (B[0][1] - B[1][1]);

    int P4 = A[1][1] * (B[1][0] - B[0][0]);

    int P5 = (A[0][0] + A[0][1]) * B[1][1];

    int P6 = (A[1][0] - A[0][0]) * (B[0][0] + B[0][1]);

    int P7 = (A[0][1] - A[1][1]) * (B[1][0] + B[1][1]);

    /*
    Compute final matrix elements
    */

    C[0][0] = P1 + P4 - P5 + P7;

    C[0][1] = P3 + P5;

    C[1][0] = P2 + P4;

    C[1][1] = P1 - P2 + P3 + P6;
}

int main() {

    int A[2][2], B[2][2], C[2][2];

    // Input first matrix
    cout << "Enter Matrix A:\n";

    for(int i = 0; i < 2; i++) {
        for(int j = 0; j < 2; j++) {
            cin >> A[i][j];
        }
    }

    // Input second matrix
    cout << "Enter Matrix B:\n";

    for(int i = 0; i < 2; i++) {
        for(int j = 0; j < 2; j++) {
            cin >> B[i][j];
        }
    }

    // Call Strassen Multiplication
    strassen(A, B, C);

    // Display result matrix
    cout << "\nResult Matrix:\n";

    for(int i = 0; i < 2; i++) {

        for(int j = 0; j < 2; j++) {
            cout << C[i][j] << " ";
        }

        cout << endl;
    }

    return 0;
}

/*
========================================================
            STRASSEN MATRIX MULTIPLICATION
========================================================

THEORY:
Strassen Algorithm multiplies matrices faster than
normal matrix multiplication.

Normal multiplication takes:
O(n^3)

Strassen takes:
O(n^2.81)

--------------------------------------------------------
WORKING:
Instead of 8 multiplications,
Strassen uses only 7 multiplications.

This reduces time complexity.

--------------------------------------------------------
FORMULAS:

P1 = (A11 + A22)(B11 + B22)
P2 = (A21 + A22)(B11)
P3 = A11(B12 - B22)
P4 = A22(B21 - B11)
P5 = (A11 + A12)(B22)
P6 = (A21 - A11)(B11 + B12)
P7 = (A12 - A22)(B21 + B22)

--------------------------------------------------------
FINAL MATRIX:

C11 = P1 + P4 - P5 + P7
C12 = P3 + P5
C21 = P2 + P4
C22 = P1 - P2 + P3 + P6

========================================================
*/

/*
--------------------------------------------------------
FUNCTION: strassen()

Purpose:
Performs Strassen Multiplication
for 2x2 matrices.
--------------------------------------------------------
*/