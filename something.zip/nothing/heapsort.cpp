#include <iostream>
using namespace std;

// Variable to count comparisons
int comparisons = 0;

void heapify(int arr[], int n, int i) {

    // Assume root is largest
    int largest = i;

    // Left child index
    int left = 2 * i + 1;

    // Right child index
    int right = 2 * i + 2;

    /*
    Compare left child with root
    */

    if(left < n) {

        comparisons++;

        if(arr[left] > arr[largest]) {
            largest = left;
        }
    }

    /*
    Compare right child with largest
    */

    if(right < n) {

        comparisons++;

        if(arr[right] > arr[largest]) {
            largest = right;
        }
    }

    /*
    If largest is not root,
    swap and heapify again
    */

    if(largest != i) {

        swap(arr[i], arr[largest]);

        heapify(arr, n, largest);
    }
}



void heapSort(int arr[], int n) {

    /*
    Build Max Heap
    */

    for(int i = n/2 - 1; i >= 0; i--) {
        heapify(arr, n, i);
    }

    /*
    Extract elements one by one
    */

    for(int i = n - 1; i > 0; i--) {

        // Move current root to end
        swap(arr[0], arr[i]);

        // Heapify reduced heap
        heapify(arr, i, 0);
    }
}

int main() {

    int n;

    // Input number of elements
    cout << "Enter number of elements: ";
    cin >> n;

    int arr[n];

    // Input array elements
    cout << "Enter elements:\n";

    for(int i = 0; i < n; i++) {
        cin >> arr[i];
    }

    // Call Heap Sort
    heapSort(arr, n);

    // Display sorted array
    cout << "\nSorted Array:\n";

    for(int i = 0; i < n; i++) {
        cout << arr[i] << " ";
    }

    // Display comparisons
    cout << "\nComparisons = " << comparisons;

    return 0;
}

/*
========================================================
                      HEAP SORT
========================================================

THEORY:
Heap Sort uses Binary Heap data structure.

A Binary Heap is a Complete Binary Tree.

In Max Heap:
Parent node is always greater than child nodes.

--------------------------------------------------------
WORKING:
1. Convert array into Max Heap.
2. Swap first element with last element.
3. Reduce heap size.
4. Heapify again.
5. Repeat until sorted.

--------------------------------------------------------
TIME COMPLEXITY:
Best Case    : O(n log n)
Worst Case   : O(n log n)
Average Case : O(n log n)

SPACE COMPLEXITY:
O(1)

--------------------------------------------------------
EXAMPLE:
Array = 4 10 3 5 1

Max Heap:
10 5 3 4 1

After Sorting:
1 3 4 5 10

========================================================
*/

/*
--------------------------------------------------------
FUNCTION: heapify()

Purpose:
Maintains Max Heap property.
--------------------------------------------------------
*/

/*
--------------------------------------------------------
FUNCTION: heapSort()

Purpose:
Performs Heap Sort.
--------------------------------------------------------
*/