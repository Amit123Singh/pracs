#include <iostream>
using namespace std;



// Variable to count comparisons
int comparisons = 0;



void merge(int arr[], int left, int mid, int right) {

    // Calculate sizes of subarrays
    int n1 = mid - left + 1;
    int n2 = right - mid;

    // Temporary arrays
    int L[n1], R[n2];

    // Copy elements into left array
    for(int i = 0; i < n1; i++) {
        L[i] = arr[left + i];
    }

    // Copy elements into right array
    for(int j = 0; j < n2; j++) {
        R[j] = arr[mid + 1 + j];
    }

    // Initial indexes
    int i = 0;
    int j = 0;
    int k = left;

    /*
    ----------------------------------------------------
    Compare elements of both arrays
    and merge them in sorted order
    ----------------------------------------------------
    */

    while(i < n1 && j < n2) {

        // Count comparison
        comparisons++;

        if(L[i] <= R[j]) {

            arr[k] = L[i];
            i++;
        }
        else {

            arr[k] = R[j];
            j++;
        }

        k++;
    }

    // Copy remaining elements of L[]
    while(i < n1) {

        arr[k] = L[i];

        i++;
        k++;
    }

    // Copy remaining elements of R[]
    while(j < n2) {

        arr[k] = R[j];

        j++;
        k++;
    }
}

/*
--------------------------------------------------------
FUNCTION: mergeSort()

Purpose:
Recursively divides array into smaller parts.
--------------------------------------------------------
*/

void mergeSort(int arr[], int left, int right) {

    // Continue dividing until single element remains
    if(left < right) {

        // Find middle index
        int mid = (left + right) / 2;

        // Sort left half
        mergeSort(arr, left, mid);

        // Sort right half
        mergeSort(arr, mid + 1, right);

        // Merge sorted halves
        merge(arr, left, mid, right);
    }
}

int main() {

    int n;

    // Input size of array
    cout << "Enter number of elements: ";
    cin >> n;

    int arr[n];

    // Input elements
    cout << "Enter elements:\n";

    for(int i = 0; i < n; i++) {
        cin >> arr[i];
    }

    // Call Merge Sort
    mergeSort(arr, 0, n - 1);

    // Display sorted array
    cout << "\nSorted Array:\n";

    for(int i = 0; i < n; i++) {
        cout << arr[i] << " ";
    }

    // Display comparisons
    cout << "\nComparisons = " << comparisons;

    return 0;
}

/*
========================================================
                      MERGE SORT
========================================================

THEORY:
Merge Sort follows Divide and Conquer technique.

1. Divide array into two halves.
2. Sort both halves recursively.
3. Merge sorted halves.

--------------------------------------------------------
TIME COMPLEXITY:
Best Case    : O(n log n)
Worst Case   : O(n log n)
Average Case : O(n log n)

SPACE COMPLEXITY:
O(n)

--------------------------------------------------------
WORKING:

Example:
Array = 8 3 5 1

Divide:
8 3 | 5 1

Further Divide:
8 | 3 | 5 | 1

Merge:
3 8 | 1 5

Final Merge:
1 3 5 8

========================================================
*/

/*
--------------------------------------------------------
FUNCTION: merge()

Purpose:
Merges two sorted subarrays into one sorted array.
--------------------------------------------------------
*/