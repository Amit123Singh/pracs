#include <iostream>
using namespace std;

// Adjacency matrix
int graph[100][100];

// Visited array
int visited[100];

// Number of vertices
int n;

void DFS(int node) {

    // Mark current node visited
    visited[node] = 1;

    // Print current node
    cout << node << " ";

    /*
    Visit all adjacent nodes
    */

    for(int i = 0; i < n; i++) {

        /*
        If edge exists and node
        is not visited
        */

        if(graph[node][i] == 1 && !visited[i]) {

            // Recursive DFS call
            DFS(i);
        }
    }
}

int main() {

    int e;

    // Input vertices and edges
    cout << "Enter number of vertices and edges: ";
    cin >> n >> e;

    // Input graph edges
    cout << "Enter edges:\n";

    for(int i = 0; i < e; i++) {

        int u, v;

        cin >> u >> v;

        // Undirected graph
        graph[u][v] = 1;
        graph[v][u] = 1;
    }

    int start;

    // Input starting node
    cout << "Enter starting vertex: ";
    cin >> start;

    cout << "\nDFS Traversal: ";

    // Call DFS function
    DFS(start);

    return 0;
}

/*
========================================================
            DEPTH FIRST SEARCH (DFS)
========================================================

THEORY:
DFS traverses graph deeply before backtracking.

It first visits one path completely,
then returns back.

DFS uses STACK internally through recursion.

--------------------------------------------------------
WORKING:
1. Start from source node.
2. Mark node as visited.
3. Visit adjacent unvisited node.
4. Repeat recursively.
5. Backtrack when no node remains.

--------------------------------------------------------
TIME COMPLEXITY:
O(V + E)

where:
V = Vertices
E = Edges

--------------------------------------------------------
APPLICATIONS:
- Path finding
- Cycle detection
- Topological sorting

========================================================
*/

/*
--------------------------------------------------------
FUNCTION: DFS()

Purpose:
Performs Depth First Traversal recursively.
--------------------------------------------------------
*/