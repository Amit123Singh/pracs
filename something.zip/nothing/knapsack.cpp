#include <iostream>
using namespace std;

int max(int a, int b) {

    if(a > b) {
        return a;
    }
    else {
        return b;
    }
}

int main() {

    int n;

    // Input number of items
    cout << "Enter number of items: ";
    cin >> n;

    /*
    Arrays for profit and weight
    */

    int profit[n];
    int weight[n];

    // Input profits
    cout << "Enter profits:\n";

    for(int i = 0; i < n; i++) {
        cin >> profit[i];
    }

    // Input weights
    cout << "Enter weights:\n";

    for(int i = 0; i < n; i++) {
        cin >> weight[i];
    }

    int W;

    // Input knapsack capacity
    cout << "Enter capacity of knapsack: ";
    cin >> W;

    /*
    DP table

    K[i][w] represents maximum profit
    using first i items and capacity w
    */

    int K[n + 1][W + 1];

    /*
    Build DP table
    */

    for(int i = 0; i <= n; i++) {

        for(int w = 0; w <= W; w++) {

            /*
            Base Case:
            If no item or capacity is 0
            */

            if(i == 0 || w == 0) {

                K[i][w] = 0;
            }

            /*
            If current item's weight
            is less than or equal to capacity
            */

            else if(weight[i - 1] <= w) {

                /*
                Two choices:

                1. Include item
                2. Exclude item

                Take maximum
                */

                K[i][w] = max(

                    profit[i - 1] +
                    K[i - 1][w - weight[i - 1]],

                    K[i - 1][w]
                );
            }

            /*
            If item cannot be included
            */

            else {

                K[i][w] = K[i - 1][w];
            }
        }
    }

    /*
    Final answer stored at
    K[n][W]
    */

    cout << "\nMaximum Profit = "
         << K[n][W];

    return 0;
}

/*
========================================================
          0-1 KNAPSACK USING DYNAMIC PROGRAMMING
========================================================

THEORY:
In 0-1 Knapsack Problem:

- Each item has:
  1. Weight
  2. Profit

- A bag has limited capacity.

Goal:
Select items to maximize total profit
without exceeding capacity.

--------------------------------------------------------
IMPORTANT:
0-1 means:
- Either take item completely
- Or do not take it

Fractional selection is NOT allowed.

--------------------------------------------------------
DYNAMIC PROGRAMMING IDEA:

For every item:
1. Include the item
2. Exclude the item

Take maximum profit among both choices.

--------------------------------------------------------
TIME COMPLEXITY:
O(n * W)

where:
n = Number of items
W = Capacity of knapsack

--------------------------------------------------------
EXAMPLE:

Items:
Profit = 60 100 120
Weight = 10 20 30

Capacity = 50

Maximum Profit = 220

========================================================
*/

/*
--------------------------------------------------------
FUNCTION: max()

Purpose:
Returns maximum of two values.
--------------------------------------------------------
*/