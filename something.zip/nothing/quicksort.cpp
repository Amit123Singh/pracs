#include <iostream>
using namespace std;

// Variable to count comparisons
int comparisons = 0;

int partition(int arr[], int low, int high) {

    // Choose last element as pivot
    int pivot = arr[high];

    // Index of smaller element
    int i = low - 1;

    /*
    Compare every element with pivot
    */

    for(int j = low; j < high; j++) {

        comparisons++;

        if(arr[j] < pivot) {

            i++;

            // Swap smaller element
            swap(arr[i], arr[j]);
        }
    }

    /*
    Place pivot at correct position
    */

    swap(arr[i + 1], arr[high]);

    return i + 1;
}

/*
--------------------------------------------------------
FUNCTION: quickSort()

Purpose:
Recursively sorts array.
--------------------------------------------------------
*/

void quickSort(int arr[], int low, int high) {

    if(low < high) {

        // Partition index
        int pi = partition(arr, low, high);

        // Sort left side
        quickSort(arr, low, pi - 1);

        // Sort right side
        quickSort(arr, pi + 1, high);
    }
}

int main() {

    int n;

    // Input size
    cout << "Enter number of elements: ";
    cin >> n;

    int arr[n];

    // Input elements
    cout << "Enter elements:\n";

    for(int i = 0; i < n; i++) {
        cin >> arr[i];
    }

    // Call Quick Sort
    quickSort(arr, 0, n - 1);

    // Display sorted array
    cout << "\nSorted Array:\n";

    for(int i = 0; i < n; i++) {
        cout << arr[i] << " ";
    }

    // Display comparisons
    cout << "\nComparisons = " << comparisons;

    return 0;
}

/*
========================================================
                      QUICK SORT
========================================================

THEORY:
Quick Sort follows Divide and Conquer approach.

It selects one element as PIVOT
and places it at correct position.

Elements smaller than pivot go left.
Elements greater than pivot go right.

--------------------------------------------------------
WORKING:
1. Choose Pivot.
2. Partition array.
3. Recursively sort left part.
4. Recursively sort right part.

--------------------------------------------------------
TIME COMPLEXITY:
Best Case    : O(n log n)
Worst Case   : O(n^2)

SPACE COMPLEXITY:
O(log n)

--------------------------------------------------------
EXAMPLE:
Array = 7 2 5 1

Pivot = 1

Partition:
1 | 7 2 5

Recursively sort remaining part:
1 2 5 7

========================================================
*/

/*
--------------------------------------------------------
FUNCTION: partition()

Purpose:
Places pivot at correct position.
--------------------------------------------------------
*/