#include <iostream>
using namespace std;
int main() {

    int n;

    // Input number of vertices
    cout << "Enter number of vertices: ";
    cin >> n;

    int cost[100][100];

    /*
    Input adjacency matrix
    */

    cout << "Enter adjacency matrix:\n";

    for(int i = 0; i < n; i++) {

        for(int j = 0; j < n; j++) {

            cin >> cost[i][j];

            /*
            Replace 0 with large value
            except diagonal
            */

            if(cost[i][j] == 0) {
                cost[i][j] = 999;
            }
        }
    }

    /*
    visited[] tracks included vertices
    */

    int visited[100] = {0};

    // Start from vertex 0
    visited[0] = 1;

    int edges = 0;

    int mincost = 0;

    cout << "\nEdges in MST:\n";

    /*
    MST contains (n - 1) edges
    */

    while(edges < n - 1) {

        int min = 999;

        int a = -1;
        int b = -1;

        /*
        Find minimum edge
        */

        for(int i = 0; i < n; i++) {

            if(visited[i]) {

                for(int j = 0; j < n; j++) {

                    /*
                    Select unvisited vertex
                    with minimum cost
                    */

                    if(!visited[j] && cost[i][j] < min) {

                        min = cost[i][j];

                        a = i;
                        b = j;
                    }
                }
            }
        }

        // Print selected edge
        cout << a << " - " << b
             << " : " << min << endl;

        // Add cost
        mincost += min;

        // Mark vertex visited
        visited[b] = 1;

        edges++;
    }

    // Print minimum cost
    cout << "\nMinimum Cost = " << mincost;

    return 0;
}

/*
========================================================
                  PRIM'S ALGORITHM
========================================================

THEORY:
Prim's Algorithm finds Minimum Spanning Tree (MST).

MST:
A tree connecting all vertices with minimum cost.

--------------------------------------------------------
WORKING:
1. Start from any vertex.
2. Select minimum weight edge.
3. Add new vertex to MST.
4. Repeat until all vertices included.

--------------------------------------------------------
TIME COMPLEXITY:
O(V^2)

--------------------------------------------------------
APPLICATIONS:
- Network design
- Road construction
- Cable wiring

========================================================
*/
